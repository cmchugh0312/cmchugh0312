import pandas as pd
import numpy as np
import sklearn
import os

os.getcwd()

os.chdir("C:/Users/crmch/OneDrive/Desktop/College/Year 2/Semester 2/Data Mining and Machine Learning")

currentDataset = pd.read_csv("irish school dataset.csv", delimiter = ';')
currentDataset.info()
currentDataset.head()

# Set the seed before random() to reproduce the result across different runs
# Replace 12345678 below with your student number
# Do not include the leading x
# Do not include leading zeros if you have any
np.random.seed(19317131)
print(np.random.random())

# Clear cells independently with a per-cell probability of 10%
currentDatasetNA = currentDataset.mask(np.random.random(currentDataset.shape) < 0.1)

# Save the data with NAs and upload it with the rest of your CA artefact files
currentDatasetNA.to_csv(r'my_ca_dataset_with_NAs.csv', index = False, header=True)

currentDataset.apply(lambda x: sum(x.isnull()), axis=0)

currentDatasetNA.loc[currentDatasetNA["Prestige_score"] == '?', "Prestige_score"] = np.NAN

currentDatasetNA.isnull().sum()[1:500]

currentDataset.describe()


