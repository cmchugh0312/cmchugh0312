#define the function to bubble sort and run the code to use bubble sort
def bubble_sort(A):
  """Sort list of comparable elements into nondecreasing order."""
  lenInner = len(A)
  for j in range(0, len(A)-1):         
    lenInner = lenInner - 1
    for k in range(0, lenInner):          
      cur = A[k]                       # current element to be tested
      next = A[k + 1]

      if cur > next:
        A[k + 1] = cur
        A[k] = next

  return A

#ask the user for their input and equal to user_input
user_input = input('Type your sentence in English lowercase please: ')
#split the string so each word is in a seperate list
split_string = user_input.split()
#print the list
print(split_string)

#sort the list using bubble sort to put the string into alphabetical order
SortedList = bubble_sort(split_string)
#print the new lists
print(SortedList)
  
# Declaring empty dictionary
dictionary = {}
  
for word in SortedList:
  
    # If key is not present in the dictionary then we will add the key and word to the dictionary
    if (word[0] not in dictionary.keys()):
  
        # Creating a sublist to store words with same key value and adding it to the list
        dictionary[word[0]] = []
        dictionary[word[0]].append(word)
  
    # If key is present then checking for the word
    else:
  
        # If word is not present in the sublist then adding it to the sublist of the proper key value
        if (word not in dictionary[word[0]]):
            dictionary[word[0]].append(word)
  
# Printing the dictionary
print(dictionary)