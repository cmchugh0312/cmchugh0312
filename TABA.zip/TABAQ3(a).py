'''from the python library time, import time for the time calculation,
import random to iterate randomly over a set of numbers,
and import matplotlib to create the plot'''
from time import time 
import random
import matplotlib.pyplot as plt

#set the start time to equal time
start_time = time()

#let r = randomisation of integers from 1-20 for a range of however much
r = [random.randint(1,20) for x in range(1, 10001)]
#print the list
print(r)
#enumerate finds duplicates in r and removes them
my_finallist = [i for j, i in enumerate(r) if i not in r[:j]]
#print the refined list
print(list(my_finallist))

#set the end time to equal time
end_time = time()

#set the elapsed time to equal to end time of the function minus the start time of the function
elapsed_time = end_time - start_time
#print this time
print(elapsed_time)

#let the count equal to the length of r to count each element in r
num_count = len(r)
#print this number
print(num_count)

#let x equal to the size of each input
x = [0, 10000, 20000, 30000, 40000, 50000, 60000, 70000, 80000, 90000, 100000, 110000, 120000]

#let y equal to the elapsed time it takes to run the code on each input
y = [0, 0.12624073028564453, 0.4238288402557373, 0.940253496170044, 1.5234911441802979, 2.3231821060180664, 3.215137004852295, 4.755687952041626, 6.101196527481079, 7.521327018737793, 8.96631507888794, 10.729160785675049, 13.392880916595459]

#use plt to plot x and y
plt.plot(x, y)

#use plt to set the labels for the x and y axis and to title the chart
plt.xlabel('size of input')
plt.ylabel('elapsed time')
plt.title('Size of Input/ Elapsed Time')

#use plt to produce the chart
plt.show()
